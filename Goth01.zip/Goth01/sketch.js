function setup() 
{
  createCanvas(300, 300);
  background(100);
}

function draw() 
{
	//Border of moon
	fill(0);
	ellipse(0, 0, 150, 150);
	stroke(20);
	
	//Moon and stars
	fill(255);
	ellipse(0, 0, 140, 140);
	ellipse(100, 75, 10, 10);
	ellipse(135, 89, 13, 13);
	ellipse(14, 120, 15, 15);
	ellipse(245, 10, 19, 19);
	ellipse(179, 45, 13, 13);
	ellipse(200, 100, 14, 14);
	ellipse(53, 139, 11, 11);
	ellipse(43, 78, 17, 17);
	ellipse(143, 25, 18, 18);
	ellipse(298, 137, 12, 12);
	ellipse(270, 83, 16, 16);
	
	
	//Horizon and buildings
	fill(0);
	line(0, 0, 150, 0);
	line(0, 150, 300, 150);
	rect(150, 175, 30, 125);
	rect(25, 200, 40, 100);
	rect(75, 125, 60, 175);
	rect(275, 125, 50, 200);
	rect(200, 250, 45, 75);


}