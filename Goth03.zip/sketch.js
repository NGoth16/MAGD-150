let rectX = 0;
let rectY = 0;
let frRate = 50;
let clr;

function setup() 
{
  createCanvas(500, 500);
  frameRate(frRate);
  clr1 = color(0, 255, 0);
  clr2 = color(255, 0, 0);
  clr3 = color(0, 0, 255);

  let varA = 25;
  let varB = 50;
  let varC = 75;
  let varD = 100;

}

function draw() 
{
	background(65);
	line(mouseX, mouseY, pmouseX, pmouseY);
	rectX = rectX + 1;
	rectY = rectY + 1;

	if (rectX >= width)
	{
		if(fr === 50)
		{
			clr = clr2;
			frRate = 60;
			frameRate(frRate);
		}
		else
		{
			clr = clr1;
			frRate = 40;
			frameRate(frRate);
		}
		rectX = 0;
	}
	
	fill(clr1);
	rect(rectX, 150, 50, 50);
	fill(clr2);
	ellipse(400, rectY, 50, 50);
	fill(clr3);
	rect(rectX, rectY, 50, 50)

	print(pmouseX + '---->' + mouseX);

}
