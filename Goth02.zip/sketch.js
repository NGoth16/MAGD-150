function setup() 
{
  createCanvas(150, 150);
  background(65);

}

function draw() 
{
	noStroke();
	colorMode(RGB, 255, 255, 255, 1);

	fill(255, 0, 0, 1);

	ellipse(10, 10, 50, 50);

	fill(50, 198, 126, 1);

	triangle(7, 89, 98, 42, 57, 72);

	fill(0, 0, 255, 1);

	quad(98, 96, 119, 70, 90, 133, 160, 96);

	fill(0, 230, 255, 1);

	arc(110, 25, 50, 50, 0, PI + QUARTER_PI);

	fill(100, 140, 39);

	beginShape(TRIANGLE_FAN);
	vertex(20, 125);
	vertex(20, 60);
	vertex(60, 125);
	vertex(20, 150);
	vertex(0, 125);
	vertex(20, 60);
	endShape();
}
